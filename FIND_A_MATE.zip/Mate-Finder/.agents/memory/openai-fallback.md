---
name: OpenAI integration fallback
description: The project’s fallback path when Replit AI Integrations cannot be provisioned
---

When the managed OpenAI setup reports that an account upgrade is required, do not retry it. Use the secure secrets flow for `OPENAI_API_KEY` and keep the key server-side.

**Why:** The managed setup can stop at an account-level billing gate; retrying does not repair it and risks blocking the user.

**How to apply:** For server-side AI features, use the OpenAI SDK with the server secret, never expose the key to browser code, and return a user-safe error when the key or provider is unavailable.