import { pgTable, serial, text, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sessionsTable = pgTable("sessions", {
  id: serial("id").primaryKey(),
  subject: text("subject").notNull(),
  hostNickname: text("host_nickname").notNull(),
  hostToken: text("host_token").notNull(),
  durationMinutes: integer("duration_minutes").notNull(),
  cooldownSeconds: integer("cooldown_seconds").notNull().default(0),
  lat: doublePrecision("lat"),
  lng: doublePrecision("lng"),
  city: text("city"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertSessionSchema = createInsertSchema(sessionsTable).omit({ id: true, createdAt: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessionsTable.$inferSelect;
