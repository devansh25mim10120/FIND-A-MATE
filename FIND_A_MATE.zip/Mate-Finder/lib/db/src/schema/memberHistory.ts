import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { sessionsTable } from "./sessions";

export const memberHistoryTable = pgTable("member_history", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => sessionsTable.id, { onDelete: "cascade" }),
  nickname: text("nickname").notNull(),
  role: text("role").notNull().default("member"),
  eventType: text("event_type").notNull().default("joined"),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
  leftAt: timestamp("left_at"),
});

export const insertMemberHistorySchema = createInsertSchema(memberHistoryTable).omit({ id: true, joinedAt: true });
export type InsertMemberHistory = z.infer<typeof insertMemberHistorySchema>;
export type MemberHistory = typeof memberHistoryTable.$inferSelect;