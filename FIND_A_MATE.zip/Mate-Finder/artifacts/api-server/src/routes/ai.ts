import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { and, asc, eq } from "drizzle-orm";
import { db, membersTable, messagesTable, sessionsTable } from "@workspace/db";
import {
  GenerateSessionSummaryParams,
  SolveSessionProblemBody,
  SolveSessionProblemParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function getOpenAI(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
  return new OpenAI({ apiKey });
}

async function getConversation(sessionId: number) {
  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, sessionId));
  if (!session) return null;

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.sessionId, sessionId))
    .orderBy(asc(messagesTable.createdAt));

  const textMessages = messages
    .filter((message) => message.type === "text" && message.content.trim())
    .map((message) => `${message.senderNickname}: ${message.content.trim()}`)
    .join("\n");

  return { session, messages, transcript: textMessages.slice(-60000) };
}

async function isSessionMember(sessionId: number, nickname: string | undefined) {
  if (!nickname?.trim()) return false;
  const [member] = await db
    .select({ id: membersTable.id })
    .from(membersTable)
    .where(and(eq(membersTable.sessionId, sessionId), eq(membersTable.nickname, nickname.trim())));
  return !!member;
}

router.post("/sessions/:sessionId/ai/summary", async (req, res): Promise<void> => {
  const params = GenerateSessionSummaryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const conversation = await getConversation(params.data.sessionId);
  if (!conversation) {
    res.status(404).json({ error: "Session not found" });
    return;
  }
  if (!(await isSessionMember(params.data.sessionId, req.headers["x-member-nickname"] as string | undefined))) {
    res.status(403).json({ error: "You must be a connected session member" });
    return;
  }
  if (conversation.messages.length === 0) {
    res.status(400).json({ error: "There are no messages to summarize yet" });
    return;
  }

  try {
    const response = await getOpenAI().chat.completions.create({
      model: "gpt-5.6-terra",
      max_completion_tokens: 8192,
      messages: [
        {
          role: "system",
          content:
            "You summarize study-group conversations. Return a clear, useful summary in markdown with these headings: What was discussed, Key insights, Decisions or answers, Open questions, and Next steps. Be faithful to the transcript and do not invent facts.",
        },
        {
          role: "user",
          content: `Session subject: ${conversation.session.subject}\n\nConversation transcript:\n${conversation.transcript}`,
        },
      ],
    });

    const summary = response.choices[0]?.message?.content?.trim();
    if (!summary) {
      res.status(502).json({ error: "The AI returned an empty summary" });
      return;
    }

    res.json({
      summary,
      messageCount: conversation.messages.length,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    req.log.error({ err: error }, "Failed to generate session summary");
    res.status(502).json({ error: "Unable to generate a summary right now" });
  }
});

router.post("/sessions/:sessionId/ai/solve", async (req, res): Promise<void> => {
  const params = SolveSessionProblemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = SolveSessionProblemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const conversation = await getConversation(params.data.sessionId);
  if (!conversation) {
    res.status(404).json({ error: "Session not found" });
    return;
  }
  if (!(await isSessionMember(params.data.sessionId, req.headers["x-member-nickname"] as string | undefined))) {
    res.status(403).json({ error: "You must be a connected session member" });
    return;
  }

  try {
    const response = await getOpenAI().chat.completions.create({
      model: "gpt-5.6-terra",
      max_completion_tokens: 8192,
      messages: [
        {
          role: "system",
          content:
            "You are a patient study-session problem-solving partner. Use the conversation as context, identify assumptions, reason step by step, and give a practical answer. If the problem is ambiguous, state what is missing and ask focused follow-up questions. Do not pretend certainty.",
        },
        {
          role: "user",
          content: `Session subject: ${conversation.session.subject}\n\nConversation context:\n${conversation.transcript || "(No text conversation yet)"}\n\nDifficult problem to solve:\n${parsed.data.problem}`,
        },
      ],
    });

    const solution = response.choices[0]?.message?.content?.trim();
    if (!solution) {
      res.status(502).json({ error: "The AI returned an empty solution" });
      return;
    }

    res.json({
      problem: parsed.data.problem,
      solution,
      messageCount: conversation.messages.length,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    req.log.error({ err: error }, "Failed to solve session problem");
    res.status(502).json({ error: "Unable to solve this problem right now" });
  }
});

export default router;