import { Router, type IRouter } from "express";
import { eq, and, gt, asc } from "drizzle-orm";
import { db, messagesTable, membersTable, sessionsTable } from "@workspace/db";
import {
  ListMessagesParams,
  ListMessagesQueryParams,
  SendMessageParams,
  SendMessageBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

const lastMessageTime = new Map<string, number>();

router.get("/sessions/:sessionId/messages", async (req, res): Promise<void> => {
  const params = ListMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const query = ListMessagesQueryParams.safeParse(req.query);
  const afterId = query.success ? query.data.after : undefined;

  const conditions = [eq(messagesTable.sessionId, params.data.sessionId)];
  if (afterId) {
    conditions.push(gt(messagesTable.id, afterId));
  }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(and(...conditions))
    .orderBy(asc(messagesTable.createdAt));

  res.json(messages);
});

router.post("/sessions/:sessionId/messages", async (req, res): Promise<void> => {
  const params = SendMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (!session.isActive) {
    res.status(400).json({ error: "Session is no longer active" });
    return;
  }

  const members = await db.select().from(membersTable).where(
    and(
      eq(membersTable.sessionId, params.data.sessionId),
      eq(membersTable.nickname, parsed.data.senderNickname),
    )
  );

  if (members.length === 0) {
    res.status(403).json({ error: "You are not a member of this session" });
    return;
  }

  if (members[0].isMuted) {
    res.status(403).json({ error: "You are muted in this session" });
    return;
  }

  if (session.cooldownSeconds > 0) {
    const key = `${params.data.sessionId}:${parsed.data.senderNickname}`;
    const last = lastMessageTime.get(key) || 0;
    const now = Date.now();
    if (now - last < session.cooldownSeconds * 1000) {
      const remaining = Math.ceil((session.cooldownSeconds * 1000 - (now - last)) / 1000);
      res.status(429).json({ error: `Please wait ${remaining} seconds before sending another message` });
      return;
    }
    lastMessageTime.set(key, now);
  }

  const [message] = await db.insert(messagesTable).values({
    sessionId: params.data.sessionId,
    senderNickname: parsed.data.senderNickname,
    type: parsed.data.type,
    content: parsed.data.content,
    fileName: parsed.data.fileName,
  }).returning();

  res.status(201).json(message);
});

export default router;
