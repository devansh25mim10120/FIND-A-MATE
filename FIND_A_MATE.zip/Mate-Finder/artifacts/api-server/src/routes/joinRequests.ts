import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, joinRequestsTable, memberHistoryTable, sessionsTable, membersTable } from "@workspace/db";
import {
  RequestJoinParams,
  RequestJoinBody,
  ListJoinRequestsParams,
  RespondJoinRequestParams,
  RespondJoinRequestBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/sessions/:sessionId/join", async (req, res): Promise<void> => {
  const params = RequestJoinParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = RequestJoinBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (!session.isActive) {
    res.status(400).json({ error: "Session is no longer active" });
    return;
  }

  const existing = await db.select().from(joinRequestsTable).where(
    and(
      eq(joinRequestsTable.sessionId, params.data.sessionId),
      eq(joinRequestsTable.nickname, parsed.data.nickname),
    )
  );

  if (existing.length > 0) {
    res.json(existing[0]);
    return;
  }

  const [request] = await db.insert(joinRequestsTable).values({
    sessionId: params.data.sessionId,
    nickname: parsed.data.nickname,
    status: "pending",
  }).returning();

  res.status(201).json(request);
});

router.get("/sessions/:sessionId/join-requests", async (req, res): Promise<void> => {
  const params = ListJoinRequestsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const requests = await db
    .select()
    .from(joinRequestsTable)
    .where(eq(joinRequestsTable.sessionId, params.data.sessionId))
    .orderBy(joinRequestsTable.createdAt);

  res.json(requests);
});

router.patch("/sessions/:sessionId/join-requests/:requestId", async (req, res): Promise<void> => {
  const params = RespondJoinRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = RespondJoinRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const hostToken = req.headers["x-host-token"] as string;
  if (!hostToken) {
    res.status(403).json({ error: "Host token required" });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session || session.hostToken !== hostToken) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const [updated] = await db
    .update(joinRequestsTable)
    .set({ status: parsed.data.status })
    .where(and(
      eq(joinRequestsTable.id, params.data.requestId),
      eq(joinRequestsTable.sessionId, params.data.sessionId),
    ))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Join request not found" });
    return;
  }

  if (parsed.data.status === "approved") {
    await db.insert(membersTable).values({
      sessionId: params.data.sessionId,
      nickname: updated.nickname,
      role: "member",
    });
    await db.insert(memberHistoryTable).values({
      sessionId: params.data.sessionId,
      nickname: updated.nickname,
      role: "member",
      eventType: "joined",
    });
  }

  res.json(updated);
});

export default router;
