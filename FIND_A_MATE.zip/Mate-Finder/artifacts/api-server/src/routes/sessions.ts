import { Router, type IRouter } from "express";
import { eq, and, sql, desc } from "drizzle-orm";
import { db, memberHistoryTable, sessionsTable, membersTable } from "@workspace/db";
import {
  CreateSessionBody,
  ListSessionsQueryParams,
  GetSessionParams,
  UpdateSessionParams,
  UpdateSessionBody,
  DeleteSessionParams,
  GetSessionStatsParams,
  GetNearbySessionsQueryParams,
} from "@workspace/api-zod";
import crypto from "crypto";

const router: IRouter = Router();

router.get("/sessions", async (req, res): Promise<void> => {
  const query = ListSessionsQueryParams.safeParse(req.query);

  const sessions = await db
    .select({
      id: sessionsTable.id,
      subject: sessionsTable.subject,
      hostNickname: sessionsTable.hostNickname,
      durationMinutes: sessionsTable.durationMinutes,
      cooldownSeconds: sessionsTable.cooldownSeconds,
      city: sessionsTable.city,
      isActive: sessionsTable.isActive,
      createdAt: sessionsTable.createdAt,
      expiresAt: sessionsTable.expiresAt,
      memberCount: sql<number>`(SELECT COUNT(*) FROM members WHERE members.session_id = ${sessionsTable.id})`.as("member_count"),
    })
    .from(sessionsTable)
    .where(eq(sessionsTable.isActive, true))
    .orderBy(desc(sessionsTable.createdAt));

  res.json(sessions);
});

router.post("/sessions", async (req, res): Promise<void> => {
  const parsed = CreateSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const hostToken = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + parsed.data.durationMinutes * 60 * 1000);

  const [session] = await db.insert(sessionsTable).values({
    subject: parsed.data.subject,
    hostNickname: parsed.data.hostNickname,
    hostToken,
    durationMinutes: parsed.data.durationMinutes,
    cooldownSeconds: parsed.data.cooldownSeconds ?? 0,
    lat: parsed.data.lat,
    lng: parsed.data.lng,
    city: parsed.data.city,
    expiresAt,
  }).returning();

  const [member] = await db.insert(membersTable).values({
    sessionId: session.id,
    nickname: parsed.data.hostNickname,
    role: "host",
  }).returning();

  await db.insert(memberHistoryTable).values({
    sessionId: session.id,
    nickname: parsed.data.hostNickname,
    role: "host",
    eventType: "joined",
  });

  res.status(201).json({
    session: {
      ...session,
      memberCount: 1,
    },
    hostToken,
    memberId: member.id,
  });
});

router.get("/sessions/nearby", async (req, res): Promise<void> => {
  const parsed = GetNearbySessionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { lat, lng, radiusKm } = parsed.data;
  const radius = radiusKm ?? 50;

  const sessions = await db
    .select({
      id: sessionsTable.id,
      subject: sessionsTable.subject,
      hostNickname: sessionsTable.hostNickname,
      durationMinutes: sessionsTable.durationMinutes,
      cooldownSeconds: sessionsTable.cooldownSeconds,
      city: sessionsTable.city,
      isActive: sessionsTable.isActive,
      createdAt: sessionsTable.createdAt,
      expiresAt: sessionsTable.expiresAt,
      lat: sessionsTable.lat,
      lng: sessionsTable.lng,
      memberCount: sql<number>`(SELECT COUNT(*) FROM members WHERE members.session_id = ${sessionsTable.id})`.as("member_count"),
    })
    .from(sessionsTable)
    .where(and(
      eq(sessionsTable.isActive, true),
      sql`${sessionsTable.lat} IS NOT NULL`,
      sql`${sessionsTable.lng} IS NOT NULL`,
    ))
    .orderBy(desc(sessionsTable.createdAt));

  const nearby = sessions
    .map((s) => {
      const dist = haversine(lat, lng, s.lat!, s.lng!);
      return {
        session: {
          id: s.id,
          subject: s.subject,
          hostNickname: s.hostNickname,
          durationMinutes: s.durationMinutes,
          cooldownSeconds: s.cooldownSeconds,
          city: s.city,
          isActive: s.isActive,
          createdAt: s.createdAt,
          expiresAt: s.expiresAt,
          memberCount: s.memberCount,
        },
        distanceKm: Math.round(dist * 10) / 10,
      };
    })
    .filter((s) => s.distanceKm <= radius)
    .sort((a, b) => a.distanceKm - b.distanceKm);

  res.json(nearby);
});

router.get("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = GetSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select({
      id: sessionsTable.id,
      subject: sessionsTable.subject,
      hostNickname: sessionsTable.hostNickname,
      durationMinutes: sessionsTable.durationMinutes,
      cooldownSeconds: sessionsTable.cooldownSeconds,
      city: sessionsTable.city,
      isActive: sessionsTable.isActive,
      createdAt: sessionsTable.createdAt,
      expiresAt: sessionsTable.expiresAt,
      memberCount: sql<number>`(SELECT COUNT(*) FROM members WHERE members.session_id = ${sessionsTable.id})`.as("member_count"),
    })
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.sessionId));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  res.json(session);
});

router.patch("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = UpdateSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const hostToken = req.headers["x-host-token"] as string;
  if (!hostToken) {
    res.status(403).json({ error: "Host token required" });
    return;
  }

  const [existing] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!existing) {
    res.status(404).json({ error: "Session not found" });
    return;
  }
  if (existing.hostToken !== hostToken) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const updateData: Record<string, unknown> = {};
  if (parsed.data.cooldownSeconds !== undefined) updateData.cooldownSeconds = parsed.data.cooldownSeconds;
  if (parsed.data.subject !== undefined) updateData.subject = parsed.data.subject;

  const [updated] = await db.update(sessionsTable).set(updateData).where(eq(sessionsTable.id, params.data.sessionId)).returning();

  const memberCount = await db.select({ count: sql<number>`count(*)` }).from(membersTable).where(eq(membersTable.sessionId, updated.id));

  res.json({ ...updated, memberCount: memberCount[0].count });
});

router.delete("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = DeleteSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const hostToken = req.headers["x-host-token"] as string;
  if (!hostToken) {
    res.status(403).json({ error: "Host token required" });
    return;
  }

  const [existing] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!existing || existing.hostToken !== hostToken) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  await db.update(sessionsTable).set({ isActive: false }).where(eq(sessionsTable.id, params.data.sessionId));
  res.sendStatus(204);
});

router.get("/sessions/:sessionId/stats", async (req, res): Promise<void> => {
  const params = GetSessionStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const [memberResult] = await db.select({ count: sql<number>`count(*)` }).from(membersTable).where(eq(membersTable.sessionId, params.data.sessionId));

  const { messagesTable } = await import("@workspace/db");
  const [messageResult] = await db.select({ count: sql<number>`count(*)` }).from(messagesTable).where(eq(messagesTable.sessionId, params.data.sessionId));

  const { joinRequestsTable } = await import("@workspace/db");
  const [pendingResult] = await db.select({ count: sql<number>`count(*)` }).from(joinRequestsTable).where(and(eq(joinRequestsTable.sessionId, params.data.sessionId), eq(joinRequestsTable.status, "pending")));

  const timeRemaining = Math.max(0, Math.floor((session.expiresAt.getTime() - Date.now()) / 1000));

  res.json({
    memberCount: memberResult.count,
    messageCount: messageResult.count,
    pendingRequests: pendingResult.count,
    timeRemainingSeconds: timeRemaining,
  });
});

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default router;
