import { Router, type IRouter } from "express";
import { eq, and, isNull } from "drizzle-orm";
import { db, memberHistoryTable, membersTable, sessionsTable } from "@workspace/db";
import {
  ListMembersParams,
  UpdateMemberParams,
  UpdateMemberBody,
  KickMemberParams,
  ListMemberHistoryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/sessions/:sessionId/members", async (req, res): Promise<void> => {
  const params = ListMembersParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const members = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.sessionId, params.data.sessionId))
    .orderBy(membersTable.joinedAt);

  res.json(members);
});

router.get("/sessions/:sessionId/member-history", async (req, res): Promise<void> => {
  const params = ListMemberHistoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const history = await db
    .select()
    .from(memberHistoryTable)
    .where(eq(memberHistoryTable.sessionId, params.data.sessionId))
    .orderBy(memberHistoryTable.joinedAt);

  res.json(history);
});

router.patch("/sessions/:sessionId/members/:memberId", async (req, res): Promise<void> => {
  const params = UpdateMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const hostToken = req.headers["x-host-token"] as string;
  if (!hostToken) {
    res.status(403).json({ error: "Host token required" });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session || session.hostToken !== hostToken) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const [updated] = await db
    .update(membersTable)
    .set({ isMuted: parsed.data.isMuted })
    .where(and(
      eq(membersTable.id, params.data.memberId),
      eq(membersTable.sessionId, params.data.sessionId),
    ))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  res.json(updated);
});

router.delete("/sessions/:sessionId/members/:memberId", async (req, res): Promise<void> => {
  const params = KickMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const hostToken = req.headers["x-host-token"] as string;
  if (!hostToken) {
    res.status(403).json({ error: "Host token required" });
    return;
  }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session || session.hostToken !== hostToken) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const [deleted] = await db
    .delete(membersTable)
    .where(and(
      eq(membersTable.id, params.data.memberId),
      eq(membersTable.sessionId, params.data.sessionId),
    ))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  await db
    .update(memberHistoryTable)
    .set({ eventType: "kicked", leftAt: new Date() })
    .where(and(
      eq(memberHistoryTable.sessionId, params.data.sessionId),
      eq(memberHistoryTable.nickname, deleted.nickname),
      isNull(memberHistoryTable.leftAt),
    ));

  res.sendStatus(204);
});

export default router;
