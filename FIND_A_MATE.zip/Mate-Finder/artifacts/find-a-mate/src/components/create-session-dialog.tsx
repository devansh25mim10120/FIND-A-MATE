import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Loader2 } from "lucide-react";
import { useCreateSession } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { setSessionCredentials, getGlobalNickname, setGlobalNickname } from "@/lib/session-store";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  subject: z.string().min(3).max(50),
  hostNickname: z.string().min(2).max(20),
  durationMinutes: z.coerce.number().min(15).max(480),
  cooldownSeconds: z.coerce.number().min(0).max(30),
  shareLocation: z.boolean().default(false),
});

export function CreateSessionDialog() {
  const [open, setOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createSession = useCreateSession();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      subject: "",
      hostNickname: getGlobalNickname(),
      durationMinutes: 60,
      cooldownSeconds: 2,
      shareLocation: false,
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      let locationData = {};
      if (values.shareLocation && "geolocation" in navigator) {
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject);
          });
          locationData = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          // Try to reverse geocode simple city name if possible, ignoring for this scope to keep simple
        } catch (e) {
          toast({
            title: "Location error",
            description: "Could not get location. Creating session without it.",
            variant: "destructive",
          });
        }
      }

      setGlobalNickname(values.hostNickname);

      createSession.mutate(
        {
          data: {
            subject: values.subject,
            hostNickname: values.hostNickname,
            durationMinutes: values.durationMinutes,
            cooldownSeconds: values.cooldownSeconds,
            ...locationData,
          },
        },
        {
          onSuccess: (data) => {
            setSessionCredentials(data.session.id, {
              nickname: values.hostNickname,
              memberId: data.memberId,
              hostToken: data.hostToken,
            });
            queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
            setOpen(false);
            setLocation(`/session/${data.session.id}`);
            toast({ title: "Session created successfully" });
          },
          onError: () => {
            toast({
              title: "Error",
              description: "Failed to create session.",
              variant: "destructive",
            });
          },
        }
      );
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="rounded-full shadow-lg gap-2 px-6 h-14 text-lg">
          <Plus className="w-6 h-6" />
          Create Session
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create a Study Session</DialogTitle>
          <DialogDescription>
            Start a new room and invite your peers to study together.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <FormField
              control={form.control}
              name="subject"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Subject / Topic</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Advanced Calculus Prep" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="hostNickname"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Nickname</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. StudyMaster99" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="durationMinutes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration</FormLabel>
                    <Select
                      onValueChange={(val) => field.onChange(parseInt(val))}
                      defaultValue={field.value.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                        <SelectItem value="120">2 hours</SelectItem>
                        <SelectItem value="240">4 hours</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="cooldownSeconds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Chat Cooldown</FormLabel>
                    <Select
                      onValueChange={(val) => field.onChange(parseInt(val))}
                      defaultValue={field.value.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select cooldown" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="0">Off</SelectItem>
                        <SelectItem value="2">2 seconds</SelectItem>
                        <SelectItem value="5">5 seconds</SelectItem>
                        <SelectItem value="10">10 seconds</SelectItem>
                        <SelectItem value="30">30 seconds</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="shareLocation"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-muted/30">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Share Location</FormLabel>
                    <FormDescription>
                      Help nearby students find your session.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            <Button
              type="submit"
              className="w-full h-12 text-lg"
              disabled={createSession.isPending}
            >
              {createSession.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
              ) : null}
              Start Session
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
