interface SessionCredentials {
  nickname: string;
  memberId: number;
  hostToken?: string;
}

export function getSessionCredentials(sessionId: number): SessionCredentials | null {
  try {
    const data = localStorage.getItem(`session_${sessionId}`);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    return null;
  }
}

export function setSessionCredentials(sessionId: number, creds: SessionCredentials) {
  localStorage.setItem(`session_${sessionId}`, JSON.stringify(creds));
}

export function clearSessionCredentials(sessionId: number) {
  localStorage.removeItem(`session_${sessionId}`);
}

export function getGlobalNickname(): string {
  return localStorage.getItem('global_nickname') || '';
}

export function setGlobalNickname(nickname: string) {
  localStorage.setItem('global_nickname', nickname);
}
