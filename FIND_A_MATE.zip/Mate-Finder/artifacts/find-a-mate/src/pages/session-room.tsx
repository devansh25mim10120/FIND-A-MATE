import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetSession,
  getGetSessionQueryKey,
  useListMembers,
  getListMembersQueryKey,
  useListMemberHistory,
  getListMemberHistoryQueryKey,
  useListMessages,
  getListMessagesQueryKey,
  useListJoinRequests,
  getListJoinRequestsQueryKey,
  useGetSessionStats,
  getGetSessionStatsQueryKey,
  useSendMessage,
  useRequestJoin,
  useGenerateSessionSummary,
  useSolveSessionProblem,
} from "@workspace/api-client-react";
import { getSessionCredentials, setSessionCredentials, getGlobalNickname, setGlobalNickname } from "@/lib/session-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  Send,
  Clock,
  Shield,
  Image as ImageIcon,
  FileText,
  Check,
  X,
  Volume2,
  VolumeX,
  UserMinus,
  ArrowLeft,
  Loader2,
  Settings,
  MessageSquare,
  History,
  Sparkles,
  Brain,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

async function hostFetch(url: string, method: string, hostToken: string, body?: unknown) {
  const opts: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json",
      "x-host-token": hostToken,
    },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  if (method === "DELETE" && res.status === 204) return null;
  return res.json();
}

export default function SessionRoom() {
  const params = useParams<{ id: string }>();
  const sessionId = parseInt(params.id || "0", 10);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [credentials, setCredentials] = useState(getSessionCredentials(sessionId));
  const [joinNickname, setJoinNickname] = useState(getGlobalNickname());
  const [messageText, setMessageText] = useState("");
  const [lastMessageId, setLastMessageId] = useState(0);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const [joinStatus, setJoinStatus] = useState<"idle" | "pending" | "approved" | "rejected">("idle");
  const [memberHistoryOpen, setMemberHistoryOpen] = useState(false);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [solveOpen, setSolveOpen] = useState(false);
  const [problemText, setProblemText] = useState("");
  const [summaryText, setSummaryText] = useState("");
  const [solutionText, setSolutionText] = useState("");

  const isHost = !!credentials?.hostToken;

  const { data: session, isLoading: sessionLoading } = useGetSession(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetSessionQueryKey(sessionId), refetchInterval: 5000 },
  });

  const { data: members } = useListMembers(sessionId, {
    query: { enabled: !!sessionId && !!credentials, queryKey: getListMembersQueryKey(sessionId), refetchInterval: 3000 },
  });

  const { data: memberHistory } = useListMemberHistory(sessionId, {
    query: { enabled: !!sessionId && !!credentials, queryKey: getListMemberHistoryQueryKey(sessionId), refetchInterval: 5000 },
  });

  const { data: messages } = useListMessages(sessionId, { after: lastMessageId > 0 ? lastMessageId : undefined }, {
    query: { enabled: !!sessionId && !!credentials, queryKey: getListMessagesQueryKey(sessionId, { after: lastMessageId > 0 ? lastMessageId : undefined }), refetchInterval: 2000 },
  });

  const { data: joinRequests } = useListJoinRequests(sessionId, {
    query: { enabled: !!sessionId && isHost, queryKey: getListJoinRequestsQueryKey(sessionId), refetchInterval: 3000 },
  });

  const { data: stats } = useGetSessionStats(sessionId, {
    query: { enabled: !!sessionId && !!credentials, queryKey: getGetSessionStatsQueryKey(sessionId), refetchInterval: 5000 },
  });

  const sendMessage = useSendMessage();
  const requestJoin = useRequestJoin();
  const aiRequest = { headers: { "x-member-nickname": credentials?.nickname ?? "" } };
  const generateSummary = useGenerateSessionSummary({ request: aiRequest });
  const solveProblem = useSolveSessionProblem({ request: aiRequest });

  const [allMessages, setAllMessages] = useState<Array<{
    id: number;
    sessionId: number;
    senderNickname: string;
    type: string;
    content: string;
    fileName?: string | null;
    createdAt: string;
  }>>([]);

  useEffect(() => {
    if (messages && messages.length > 0) {
      setAllMessages((prev) => {
        const existingIds = new Set(prev.map((m) => m.id));
        const newMsgs = messages.filter((m) => !existingIds.has(m.id));
        if (newMsgs.length === 0) return prev;
        const merged = [...prev, ...newMsgs];
        const maxId = Math.max(...merged.map((m) => m.id));
        setLastMessageId(maxId);
        return merged;
      });
    }
  }, [messages]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [allMessages]);

  useEffect(() => {
    if (cooldownRemaining > 0) {
      const timer = setTimeout(() => setCooldownRemaining((c) => c - 1), 1000);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [cooldownRemaining]);

  const handleSendMessage = useCallback(
    (type: string, content: string, fileName?: string) => {
      if (!credentials || !content.trim()) return;
      sendMessage.mutate(
        {
          sessionId,
          data: {
            senderNickname: credentials.nickname,
            type: type as "text" | "image" | "file",
            content,
            fileName,
          },
        },
        {
          onSuccess: () => {
            setMessageText("");
            if (session?.cooldownSeconds && session.cooldownSeconds > 0) {
              setCooldownRemaining(session.cooldownSeconds);
            }
            queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(sessionId) });
          },
          onError: (err: unknown) => {
            const apiErr = err as { data?: { error?: string } };
            const msg = apiErr?.data?.error || "Failed to send message";
            toast({ title: "Error", description: msg, variant: "destructive" });
          },
        }
      );
    },
    [credentials, session, sessionId, sendMessage, queryClient, toast]
  );

  const handleFileUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        const isImage = file.type.startsWith("image/");
        handleSendMessage(isImage ? "image" : "file", base64, file.name);
      };
      reader.readAsDataURL(file);
      e.target.value = "";
    },
    [handleSendMessage]
  );

  const handleJoinRequest = () => {
    if (!joinNickname.trim()) return;
    setGlobalNickname(joinNickname);
    requestJoin.mutate(
      { sessionId, data: { nickname: joinNickname } },
      {
        onSuccess: (data) => {
          if (data.status === "approved") {
            setJoinStatus("approved");
            setCredentials({ nickname: joinNickname, memberId: data.id });
            setSessionCredentials(sessionId, { nickname: joinNickname, memberId: data.id });
          } else if (data.status === "rejected") {
            setJoinStatus("rejected");
          } else {
            setJoinStatus("pending");
            pollJoinStatus(data.id);
          }
        },
        onError: () => {
          toast({ title: "Error", description: "Failed to send join request", variant: "destructive" });
        },
      }
    );
  };

  const pollJoinStatus = (requestId: number) => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/sessions/${sessionId}/join-requests`);
        const requests = await res.json();
        const myReq = requests.find((r: { id: number }) => r.id === requestId);
        if (myReq) {
          if (myReq.status === "approved") {
            clearInterval(interval);
            setJoinStatus("approved");
            const membersRes = await fetch(`/api/sessions/${sessionId}/members`);
            const membersList = await membersRes.json();
            const me = membersList.find((m: { nickname: string }) => m.nickname === joinNickname);
            if (me) {
              setCredentials({ nickname: joinNickname, memberId: me.id });
              setSessionCredentials(sessionId, { nickname: joinNickname, memberId: me.id });
            }
          } else if (myReq.status === "rejected") {
            clearInterval(interval);
            setJoinStatus("rejected");
          }
        }
      } catch {
        /* ignore polling errors */
      }
    }, 2000);
  };

  const handleRespondJoin = async (requestId: number, status: "approved" | "rejected") => {
    if (!credentials?.hostToken) return;
    await hostFetch(`/api/sessions/${sessionId}/join-requests/${requestId}`, "PATCH", credentials.hostToken, { status });
    queryClient.invalidateQueries({ queryKey: getListJoinRequestsQueryKey(sessionId) });
    queryClient.invalidateQueries({ queryKey: getListMembersQueryKey(sessionId) });
  };

  const handleMuteMember = async (memberId: number, isMuted: boolean) => {
    if (!credentials?.hostToken) return;
    await hostFetch(`/api/sessions/${sessionId}/members/${memberId}`, "PATCH", credentials.hostToken, { isMuted });
    queryClient.invalidateQueries({ queryKey: getListMembersQueryKey(sessionId) });
  };

  const handleKickMember = async (memberId: number) => {
    if (!credentials?.hostToken) return;
    await hostFetch(`/api/sessions/${sessionId}/members/${memberId}`, "DELETE", credentials.hostToken);
    queryClient.invalidateQueries({ queryKey: getListMembersQueryKey(sessionId) });
    toast({ title: "Member kicked" });
  };

  const handleUpdateCooldown = async (value: string) => {
    if (!credentials?.hostToken) return;
    await hostFetch(`/api/sessions/${sessionId}`, "PATCH", credentials.hostToken, { cooldownSeconds: parseInt(value) });
    queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey(sessionId) });
    toast({ title: "Cooldown updated" });
  };

  const handleEndSession = async () => {
    if (!credentials?.hostToken) return;
    await hostFetch(`/api/sessions/${sessionId}`, "DELETE", credentials.hostToken);
    toast({ title: "Session ended" });
    navigate("/");
  };

  const handleGenerateSummary = () => {
    setSummaryOpen(true);
    setSummaryText("");
    generateSummary.mutate(
      { sessionId },
      {
        onSuccess: (data) => setSummaryText(data.summary),
        onError: (error: unknown) => {
          const apiErr = error as { data?: { error?: string } };
          toast({
            title: "Summary unavailable",
            description: apiErr?.data?.error || "Unable to generate a summary right now.",
            variant: "destructive",
          });
        },
      },
    );
  };

  const handleSolveProblem = () => {
    if (!problemText.trim()) return;
    setSolutionText("");
    solveProblem.mutate(
      { sessionId, data: { problem: problemText.trim() } },
      {
        onSuccess: (data) => setSolutionText(data.solution),
        onError: (error: unknown) => {
          const apiErr = error as { data?: { error?: string } };
          toast({
            title: "Problem solving unavailable",
            description: apiErr?.data?.error || "Unable to solve this problem right now.",
            variant: "destructive",
          });
        },
      },
    );
  };

  if (sessionLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-lg text-muted-foreground">Session not found</p>
        <Button asChild variant="outline">
          <Link href="/">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Link>
        </Button>
      </div>
    );
  }

  if (!credentials) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="w-full max-w-md mx-4">
          <CardHeader>
            <CardTitle className="text-xl">Join: {session.subject}</CardTitle>
            <p className="text-sm text-muted-foreground">Hosted by {session.hostNickname}</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {joinStatus === "idle" && (
              <>
                <Input
                  placeholder="Enter your nickname"
                  value={joinNickname}
                  onChange={(e) => setJoinNickname(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleJoinRequest()}
                  data-testid="input-join-nickname"
                />
                <Button
                  className="w-full"
                  onClick={handleJoinRequest}
                  disabled={!joinNickname.trim() || requestJoin.isPending}
                  data-testid="button-join-request"
                >
                  {requestJoin.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Request to Join
                </Button>
              </>
            )}
            {joinStatus === "pending" && (
              <div className="text-center space-y-3 py-4">
                <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
                <p className="text-muted-foreground">Waiting for host approval...</p>
              </div>
            )}
            {joinStatus === "rejected" && (
              <div className="text-center space-y-3 py-4">
                <X className="w-8 h-8 mx-auto text-destructive" />
                <p className="text-destructive">Your request was rejected.</p>
                <Button variant="outline" onClick={() => setJoinStatus("idle")}>Try Again</Button>
              </div>
            )}
            <Button variant="ghost" className="w-full" asChild>
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const timeRemaining = stats?.timeRemainingSeconds ?? 0;
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;

  const pendingRequests = joinRequests?.filter((r) => r.status === "pending") || [];

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]">
      <div className="border-b bg-card/50 px-4 py-3 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild className="shrink-0">
            <Link href="/">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </Button>
          <div>
            <h2 className="font-bold text-lg leading-tight" data-testid="text-session-subject">{session.subject}</h2>
            <p className="text-xs text-muted-foreground">
              Hosted by {session.hostNickname}
              {session.city ? ` -- ${session.city}` : ""}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="gap-1.5 font-mono text-sm px-3 py-1">
            <Clock className="w-4 h-4" />
            {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
          </Badge>
          <Badge variant="outline" className="gap-1.5 px-3 py-1">
            <Users className="w-4 h-4" />
            {members?.length ?? 0}
          </Badge>
          <Badge variant="outline" className="gap-1.5 px-3 py-1">
            <MessageSquare className="w-4 h-4" />
            {stats?.messageCount ?? 0}
          </Badge>
          {isHost && (
            <>
              {pendingRequests.length > 0 && (
                <Badge variant="destructive" className="px-3 py-1">
                  {pendingRequests.length} pending
                </Badge>
              )}
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon" data-testid="button-host-settings">
                    <Settings className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Host Controls</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6 pt-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Message Cooldown</label>
                      <Select
                        value={String(session.cooldownSeconds)}
                        onValueChange={handleUpdateCooldown}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">Off</SelectItem>
                          <SelectItem value="2">2 seconds</SelectItem>
                          <SelectItem value="5">5 seconds</SelectItem>
                          <SelectItem value="10">10 seconds</SelectItem>
                          <SelectItem value="30">30 seconds</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Separator />
                    <Button variant="destructive" className="w-full" onClick={handleEndSession} data-testid="button-end-session">
                      End Session
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </>
          )}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 flex flex-col">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-3 max-w-3xl mx-auto">
              {allMessages.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  No messages yet. Say something to get the conversation going!
                </div>
              )}
              {allMessages.map((msg) => {
                const isMe = msg.senderNickname === credentials.nickname;
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                    data-testid={`message-${msg.id}`}
                  >
                    <div
                      className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
                        isMe
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-muted rounded-bl-md"
                      }`}
                    >
                      {!isMe && (
                        <p className="text-xs font-semibold mb-1 opacity-70">{msg.senderNickname}</p>
                      )}
                      {msg.type === "text" && <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>}
                      {msg.type === "image" && (
                        <div className="space-y-1">
                          <img
                            src={msg.content}
                            alt={msg.fileName || "Shared image"}
                            className="max-w-full rounded-lg max-h-64 object-contain"
                          />
                          {msg.fileName && (
                            <p className="text-xs opacity-70">{msg.fileName}</p>
                          )}
                        </div>
                      )}
                      {msg.type === "file" && (
                        <a
                          href={msg.content}
                          download={msg.fileName || "file"}
                          className="flex items-center gap-2 text-sm underline"
                        >
                          <FileText className="w-4 h-4 shrink-0" />
                          {msg.fileName || "Download file"}
                        </a>
                      )}
                      <p className="text-[10px] mt-1 opacity-50">
                        {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={chatEndRef} />
            </div>
          </ScrollArea>

          <div className="border-t p-3 bg-card/50">
            <div className="flex gap-2 max-w-3xl mx-auto">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                className="hidden"
                accept="image/*,.pdf,.doc,.docx,.txt,.zip"
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                className="shrink-0"
                data-testid="button-attach-file"
              >
                <ImageIcon className="w-5 h-5" />
              </Button>
              <Input
                placeholder={cooldownRemaining > 0 ? `Wait ${cooldownRemaining}s...` : "Type a message..."}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage("text", messageText);
                  }
                }}
                disabled={cooldownRemaining > 0}
                className="flex-1"
                data-testid="input-message"
              />
              <Button
                size="icon"
                onClick={() => handleSendMessage("text", messageText)}
                disabled={!messageText.trim() || cooldownRemaining > 0 || sendMessage.isPending}
                data-testid="button-send-message"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        <div className="w-72 border-l bg-card/30 hidden lg:flex flex-col">
          <div className="p-4 border-b">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Users className="w-4 h-4" />
              Members ({members?.length ?? 0})
            </h3>
          </div>
          <ScrollArea className="flex-1 p-3">
            <div className="space-y-2">
              {members?.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-muted/50"
                  data-testid={`member-${member.id}`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-2 h-2 rounded-full shrink-0 ${member.isMuted ? "bg-destructive" : "bg-green-500"}`} />
                    <span className="text-sm truncate">{member.nickname}</span>
                    {member.role === "host" && (
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0 shrink-0">
                        <Shield className="w-3 h-3 mr-0.5" />
                        Host
                      </Badge>
                    )}
                    {member.isMuted && (
                      <VolumeX className="w-3.5 h-3.5 text-destructive shrink-0" />
                    )}
                  </div>
                  {isHost && member.role !== "host" && (
                    <div className="flex gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => handleMuteMember(member.id, !member.isMuted)}
                        title={member.isMuted ? "Unmute" : "Mute"}
                      >
                        {member.isMuted ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => handleKickMember(member.id)}
                        title="Kick"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>

          {isHost && pendingRequests.length > 0 && (
            <div className="border-t p-3">
              <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Pending Requests ({pendingRequests.length})
              </h3>
              <div className="space-y-2">
                {pendingRequests.map((req) => (
                  <div
                    key={req.id}
                    className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-muted/50"
                  >
                    <span className="text-sm truncate">{req.nickname}</span>
                    <div className="flex gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-green-600 hover:text-green-700"
                        onClick={() => handleRespondJoin(req.id, "approved")}
                        data-testid={`button-approve-${req.id}`}
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => handleRespondJoin(req.id, "rejected")}
                        data-testid={`button-reject-${req.id}`}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="border-t p-3 space-y-2">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              Session tools
            </h3>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => setMemberHistoryOpen(true)}
            >
              <History className="w-4 h-4" />
              Member history
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={handleGenerateSummary}
              disabled={generateSummary.isPending}
            >
              {generateSummary.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Summarize conversation
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={() => setSolveOpen(true)}
            >
              <Brain className="w-4 h-4" />
              Solve a difficult problem
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={memberHistoryOpen} onOpenChange={setMemberHistoryOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Member connection history</DialogTitle>
          </DialogHeader>
          <div className="text-sm text-muted-foreground">
            Everyone who joined this meeting, including people who were later removed.
          </div>
          <ScrollArea className="max-h-[50vh] pr-4">
            <div className="space-y-2">
              {memberHistory?.length ? memberHistory.map((entry) => (
                <div key={entry.id} className="flex items-center justify-between gap-3 rounded-lg border bg-muted/30 px-3 py-2">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{entry.nickname}</p>
                    <p className="text-xs text-muted-foreground">
                      Joined {new Date(entry.joinedAt).toLocaleString()}
                    </p>
                    {entry.leftAt && (
                      <p className="text-xs text-muted-foreground">
                        {entry.eventType === "kicked" ? "Removed" : "Left"} {new Date(entry.leftAt).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <Badge variant={entry.leftAt ? "secondary" : "default"} className="shrink-0">
                    {entry.leftAt ? (entry.eventType === "kicked" ? "Kicked" : "Left") : "Connected"}
                  </Badge>
                </div>
              )) : (
                <p className="py-8 text-center text-sm text-muted-foreground">No member history yet.</p>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={summaryOpen} onOpenChange={setSummaryOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Conversation summary</DialogTitle>
          </DialogHeader>
          {generateSummary.isPending ? (
            <div className="flex items-center gap-2 py-8 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin" />
              Reading the full conversation...
            </div>
          ) : summaryText ? (
            <ScrollArea className="max-h-[60vh]">
              <div className="whitespace-pre-wrap rounded-lg bg-muted/40 p-4 text-sm leading-6">{summaryText}</div>
            </ScrollArea>
          ) : (
            <p className="py-8 text-center text-muted-foreground">Send a few messages first, then generate a summary.</p>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={solveOpen} onOpenChange={setSolveOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Get help with a difficult problem</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            The AI will use this meeting’s conversation as context before suggesting a solution.
          </p>
          <textarea
            className="min-h-28 w-full rounded-md border bg-background px-3 py-2 text-sm outline-none ring-offset-background placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
            placeholder="Describe the problem the group is stuck on..."
            value={problemText}
            onChange={(event) => setProblemText(event.target.value)}
            maxLength={4000}
          />
          <Button onClick={handleSolveProblem} disabled={!problemText.trim() || solveProblem.isPending}>
            {solveProblem.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
            {solveProblem.isPending ? "Working through it..." : "Solve with AI"}
          </Button>
          {solutionText && (
            <ScrollArea className="max-h-[45vh]">
              <div className="whitespace-pre-wrap rounded-lg bg-muted/40 p-4 text-sm leading-6">{solutionText}</div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
