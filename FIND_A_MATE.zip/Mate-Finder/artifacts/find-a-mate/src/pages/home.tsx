import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  useListSessions,
  getListSessionsQueryKey,
  useGetNearbySessions,
  getGetNearbySessionsQueryKey,
} from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Clock, MapPin, Search, Plus } from "lucide-react";
import { CreateSessionDialog } from "@/components/create-session-dialog";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);

  const { data: sessions, isLoading } = useListSessions();
  
  const { data: nearbySessions } = useGetNearbySessions(
    location ? { lat: location.lat, lng: location.lng } : { lat: 0, lng: 0 },
    { query: { enabled: !!location, queryKey: getGetNearbySessionsQueryKey({ lat: location?.lat ?? 0, lng: location?.lng ?? 0, radiusKm: 50 }) } }
  );

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      });
    }
  }, []);

  const filteredSessions = sessions?.filter((session) =>
    session.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    session.hostNickname.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8 space-y-12">
      <section className="flex flex-col md:flex-row gap-6 items-center justify-between">
        <div className="space-y-2 text-center md:text-left">
          <h1 className="text-4xl font-bold tracking-tight text-foreground">Find A Mate</h1>
          <p className="text-lg text-muted-foreground">Real-time collaborative study sessions.</p>
        </div>
        <CreateSessionDialog />
      </section>

      <section className="space-y-6">
        <div className="relative max-w-md mx-auto md:mx-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search by subject or host..."
            className="pl-10 h-12 text-lg rounded-full bg-card"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {nearbySessions && nearbySessions.length > 0 && !searchQuery && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold flex items-center gap-2">
              <MapPin className="w-6 h-6 text-primary" />
              Sessions Near You
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {nearbySessions.map(({ session, distanceKm }) => (
                <SessionCard key={session.id} session={session} distanceKm={distanceKm} />
              ))}
            </div>
          </div>
        )}

        <div className="space-y-4">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Clock className="w-6 h-6 text-primary" />
            Active Sessions
          </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map(i => (
                <Card key={i} className="animate-pulse h-48 bg-muted" />
              ))}
            </div>
          ) : filteredSessions?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredSessions.map((session) => (
                <SessionCard key={session.id} session={session} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground bg-card rounded-xl border border-dashed">
              No active sessions found. Be the first to create one!
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function SessionCard({ session, distanceKm }: { session: any, distanceKm?: number }) {
  return (
    <Card className="flex flex-col hover-elevate hover:border-primary/50 transition-colors overflow-hidden group">
      <CardHeader className="pb-3 border-b bg-muted/30">
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="line-clamp-1 text-lg font-bold" title={session.subject}>
            {session.subject}
          </CardTitle>
          <Badge variant="secondary" className="shrink-0 rounded-sm font-mono text-xs">
            {session.durationMinutes}m
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground font-medium">Host: {session.hostNickname}</p>
      </CardHeader>
      <CardContent className="py-4 flex-1">
        <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5 bg-background px-2.5 py-1 rounded-md border">
            <Users className="w-4 h-4 text-primary" />
            <span className="font-semibold">{session.memberCount} joined</span>
          </div>
          {session.city && (
            <div className="flex items-center gap-1.5 bg-background px-2.5 py-1 rounded-md border">
              <MapPin className="w-4 h-4 text-secondary" />
              <span className="truncate max-w-[120px]">{session.city}</span>
            </div>
          )}
          {distanceKm !== undefined && (
            <div className="flex items-center gap-1.5 bg-background px-2.5 py-1 rounded-md border text-xs font-mono">
              ~{distanceKm.toFixed(1)}km away
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button asChild className="w-full rounded-lg shadow-sm group-hover:shadow-md transition-shadow">
          <Link href={`/session/${session.id}`}>Join Session</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
